Residual-colored scatter plot with two-axis error bars | 残差着色散点图＋双向误差线

Use Rscript --vanilla draw_figure.R output from the extracted directory.
Required: R with ggplot2, cowplot, ragg, systemfonts and Arial. Tested on macOS; other platforms use Cairo PDF when available.

Credit: Taylor L. Mighell and Ben Lehner, GPCR-MAPS, Nature Structural & Molecular Biology (2026), Fig. 4c Source Data.
Original figure: https://www.nature.com/articles/s41594-026-01907-3/figures/4
Original data: https://static-content.springer.com/esm/art%3A10.1038%2Fs41594-026-01907-3/MediaObjects/41594_2026_1907_MOESM7_ESM.xlsx
Author code: https://github.com/lehner-lab/GPCR-MAPS/blob/8698965e61e664d128708d03aec4fb8d6593865a/Figure_4.ipynb
Data license: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
Changes: Extracted paired recruitment scores and published residuals; recovered fitted y by subtracting the residual. Recolored and labeled the highlighted variants.
The BioFigure R code is distributed under the accompanying MIT license.
