Genomic score profile with gene track and structure callouts

Source: Lake et al., Nature 635, 390–397 (2024), Fig. 4a
https://doi.org/10.1038/s41586-024-08048-x
Published Figure4a-b workbook (position-level source values):
https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-024-08048-x/MediaObjects/41586_2024_8048_MOESM5_ESM.xlsx
Author plotting code and locus inputs, GitHub revision a29fb96beda655b626f043cd266a06afe0b103c5:
https://github.com/leklab/mitochondrial_constraint/tree/a29fb96beda655b626f043cd266a06afe0b103c5/figure_scripts
Structure views independently projected from deposited wwPDB coordinate data (CC0):
https://www.rcsb.org/structure/6ZSE (human mitoribosome)
https://www.rcsb.org/structure/5Z62 (human complex IV)
https://www.rcsb.org/structure/6ZKM (ovine complex I with rotenone)
https://www.wwpdb.org/about/usage-policies

Files: draw_figure.R and four plot_data CSVs (published MLC scores, named gene intervals,
genome-to-structure callout positions, and projected structure drawing primitives).
Run: Rscript draw_figure.R
Requirements: BioFigure 3.8, Arial, Ghostscript, ggplot2, cowplot, ragg, systemfonts,
yaml and jsonlite. Set BIOFIGURE_ROOT if BioFigure is installed outside ~/.codex/skills/biofigure.
