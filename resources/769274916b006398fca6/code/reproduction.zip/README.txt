Block heatmaps with horizontal boxplots

Paper: Navarrete et al. (2026), Fig. 3b (left and center)
https://doi.org/10.1038/s41588-026-02672-1
Publisher or repository data: https://static-content.springer.com/esm/art%3A10.1038%2Fs41588-026-02672-1/MediaObjects/41588_2026_2672_MOESM5_ESM.xlsx
Author code: https://github.com/sebepedroslab/iChIPv2/tree/main/Paper_analysis

Files: draw_figure.R and the processed numeric drawing tables in plot_data/.
Run: Rscript draw_figure.R
Requires BioFigure 3.8, Arial, Ghostscript, ragg, systemfonts, yaml, jsonlite,
plus ggplot2, cowplot, scales. Set BIOFIGURE_ROOT to the BioFigure skill directory
if it is installed outside ~/.codex/skills/biofigure.
