Rotated triangular heatmaps

Adapted from Ruxandra A. Lambuta, Luca Nanni, Yuanlong Liu, Juan Diaz-Miyar,
Arvind Iyer, Daniele Tavernari, Natalya Katanayeva, Giovanni Ciriello and
Elisa Oricchio, Nature (2023), Fig. 1d–e.
https://doi.org/10.1038/s41586-023-05794-2
© The Author(s) 2023. Source article and panels licensed CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/
BioFigure independently redrew the rotated tiles and assembled the panel layout
from the publisher's numeric source tables.

Publisher Source Data Fig. 1:
https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-023-05794-2/MediaObjects/41586_2023_5794_MOESM10_ESM.xlsx
Author analysis code:
https://github.com/CSOgroup/WGD/blob/0d79f37faa2499cb1bd2a2ddf2264fe41b39e716/src/02_LCS.py
UCSC hg19 chromosome sizes:
https://hgdownload.soe.ucsc.edu/goldenPath/hg19/bigZips/hg19.chrom.sizes

Download the publisher workbook and UCSC chromosome sizes. Adjust the example
filenames below if needed. The archive contains the independent plotting and
workbook extraction scripts.

python3 extract_source.py 41586_2023_5794_MOESM10_ESM.xlsx data
awk 'BEGIN {OFS="	"; print "chromosome", "length"} $1 ~ /^chr([1-9]|1[0-9]|2[0-2]|X)$/ {print $1, $2}' hg19.chrom.sizes > data/hg19-order.tsv
Rscript draw_figure.R data results

Requirements: Python 3, R, Arial, ggplot2, cowplot, ragg, systemfonts, jsonlite
and a working Quartz or Cairo PDF device. BIOFIGURE_STYLE_R may optionally
point to BioFigure's figure_style.R for additional validation.
