Circular phylogenetic trees with branch loadings

Paper: Duchêne et al. (2025), Fig. 2c
https://doi.org/10.1038/s41586-025-08777-7
Publisher or repository data: https://doi.org/10.6084/m9.figshare.27323229.v1
Author code: https://github.com/duchene/avian_family_rates/blob/main/Supp_Data_5_scripts/5_process_pc_data.Rscript#L133-L167

Files: draw_figure.R and the processed numeric drawing tables in plot_data/.
Run: Rscript draw_figure.R
Requires BioFigure 3.8, Arial, Ghostscript, ragg, systemfonts, yaml, jsonlite,
plus ggplot2, png, rsvg. Set BIOFIGURE_ROOT to the BioFigure skill directory
if it is installed outside ~/.codex/skills/biofigure.

Numeric PCA inputs and tree: Duchêne et al., Figshare, CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/

Independent public-domain PhyloPic silhouettes used in the redrawn figure:
Accipiter nisus — Andy Wilson — CC0 1.0 Universal Public Domain Dedication
https://www.phylopic.org/images/2cc4c508-2a2e-459d-bcc7-5a40c0ed8ffb/accipiter-nisus
https://creativecommons.org/publicdomain/zero/1.0/
cariama-cristata — George Edward Lodge (vectorized by T. Michael Keesey) — Public Domain Mark 1.0
https://www.phylopic.org/images/694ae92f-857d-4675-838b-2a9f8fa65583/cariama-cristata
https://creativecommons.org/publicdomain/mark/1.0/
gavia-immer — Marie Attard — Public Domain Mark 1.0
https://www.phylopic.org/images/db5c0243-52bf-4a2b-a27c-0a0c34469522/gavia-immer
https://creativecommons.org/publicdomain/mark/1.0/
trogon — Ferran Sayol — CC0 1.0 Universal Public Domain Dedication
https://www.phylopic.org/images/5eca6929-759a-482c-b29c-b78340c35143/trogon
https://creativecommons.org/publicdomain/zero/1.0/
