Signed scatter plot with threshold guides

Source: Scheer, Landau et al., Nature Communications 17, 3822 (2026), Fig. 2a
https://doi.org/10.1038/s41467-026-71450-8
Author R and public summary data at GitHub revision 1fad1af6abf80a85d556e27aec4ad8aa66c1f2f1:
https://github.com/kendrasc/Andean_Amylase_Project/tree/1fad1af6abf80a85d556e27aec4ad8aa66c1f2f1/Figure_2

Independent ggplot2 drawing from per-SNV summary numbers. The authors tested 267142
SNVs and dropped 80064 points whose two coordinates were both zero from the display.
The signed Kruskal-Wallis transform, directional FST and signed joint product copy the
original numerical values. Two rsIDs were joined by Ensembl GRCh38 chr1 coordinates.
The three numbered guides are illustrative regions drawn to match the paper's emphasis.
Population direction follows the original Alt-allele frequency orientation.

Files: draw_figure.R and three plot_data CSVs (points, cutoff guides and highlight geometry).
Run: Rscript draw_figure.R
Requires BioFigure 3.8, Arial, Ghostscript, ggplot2, cowplot, ragg, systemfonts,
yaml and jsonlite. Set BIOFIGURE_ROOT if BioFigure is installed outside ~/.codex/skills/biofigure.
