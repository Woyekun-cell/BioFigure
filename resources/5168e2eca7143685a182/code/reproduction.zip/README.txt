Triangular correlation heatmap with violins and a dendrogram

Paper: Gong, Mian et al. (2026), Fig. 5a
https://doi.org/10.1038/s41588-026-02825-2
Publisher or repository data: https://static-content.springer.com/esm/art%3A10.1038%2Fs41588-026-02825-2/MediaObjects/41588_2026_2825_MOESM9_ESM.xlsx
Author code: https://github.com/FarmGTEx/SheepGTEx-Pipeline-v0/blob/main/figure/Fig5a.R

Files: draw_figure.R and the processed numeric drawing tables in plot_data/.
Run: Rscript draw_figure.R
Requires BioFigure 3.8, Arial, Ghostscript, ragg, systemfonts, yaml, jsonlite,
plus ggplot2, cowplot, dendextend, ggdendro. Set BIOFIGURE_ROOT to the BioFigure skill directory
if it is installed outside ~/.codex/skills/biofigure.
