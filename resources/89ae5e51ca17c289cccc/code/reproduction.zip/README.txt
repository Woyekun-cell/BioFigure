Scatter plot with marginal densities

Adapted from Ruxandra A. Lambuta, Luca Nanni, Yuanlong Liu, Juan Diaz-Miyar,
Arvind Iyer, Daniele Tavernari, Natalya Katanayeva, Giovanni Ciriello and
Elisa Oricchio, Nature (2023), Fig. 3c.
https://doi.org/10.1038/s41586-023-05794-2
© The Author(s) 2023. The source article and panels use CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/
BioFigure independently redrew the source-data comparison in R.

Publisher Source Data Fig. 3:
https://static-content.springer.com/esm/art%3A10.1038%2Fs41586-023-05794-2/MediaObjects/41586_2023_5794_MOESM12_ESM.xlsx
Author analysis code:
https://github.com/CSOgroup/WGD/blob/0d79f37faa2499cb1bd2a2ddf2264fe41b39e716/src/04_scHiC.py

Download the publisher workbook and unzip this archive in a new directory.
Run the extraction and R rendering from that directory.

python3 extract_source.py 41586_2023_5794_MOESM12_ESM.xlsx .
Rscript draw_figure.R data results

Requirements: Python 3, R, Arial, ggplot2, ragg, systemfonts, jsonlite
and a working Quartz or Cairo PDF device.
