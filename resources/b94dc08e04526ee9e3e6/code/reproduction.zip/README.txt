UpSet plot with locator map | UpSet 图＋定位地图

Use Rscript --vanilla draw_figure.R output from the extracted directory.
Required: R with ggplot2, cowplot, ragg, systemfonts and Arial. Tested on macOS; other platforms use Cairo PDF when available.

Credit: Marshall et al., bee checklists (Zenodo 23222636); Dinerstein et al., RESOLVE Ecoregions 2017 (doi:10.1093/biosci/bix014).
Original figure: https://www.nature.com/articles/s41586-026-11325-6/figures/1
Original data: https://zenodo.org/records/23222636
Author code: https://zenodo.org/records/23222636/files/R%20Code.zip?download=1
Data license: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
Changes: Author lists summarized into 25 exclusive intersections; RESOLVE vectors grouped by realm, projected to Eckert IV, simplified and recolored. Map layer: https://services.arcgis.com/P3ePLMYs2RVChkJx/ArcGIS/rest/services/Resolve_Ecoregions/FeatureServer/0
The BioFigure R code is distributed under the accompanying MIT license.
